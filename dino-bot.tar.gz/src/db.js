import Database from 'better-sqlite3'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'
import * as dotenv from 'dotenv'
dotenv.config()

const __dirname = dirname(fileURLToPath(import.meta.url))
const dbPath = join(__dirname, '..', process.env.DB_PATH || './data/dinos.db')

const db = new Database(dbPath)
db.pragma('journal_mode = WAL')

db.exec(`
  CREATE TABLE IF NOT EXISTS dinos (
    phone        TEXT PRIMARY KEY,
    name         TEXT DEFAULT NULL,
    stage        TEXT DEFAULT 'egg',
    hunger       INTEGER DEFAULT 100,
    happiness    INTEGER DEFAULT 100,
    xp           INTEGER DEFAULT 0,
    interactions INTEGER DEFAULT 0,
    url_feeds    INTEGER DEFAULT 0,
    personality  TEXT DEFAULT '[]',
    memories     TEXT DEFAULT '[]',
    history      TEXT DEFAULT '[]',
    created_at   INTEGER DEFAULT (strftime('%s','now')),
    last_seen    INTEGER DEFAULT (strftime('%s','now'))
  );
`)

// --- Dino CRUD ---

export function getDino(phone) {
  const row = db.prepare('SELECT * FROM dinos WHERE phone = ?').get(phone)
  if (!row) return null
  return {
    ...row,
    personality: JSON.parse(row.personality),
    memories:    JSON.parse(row.memories),
    history:     JSON.parse(row.history),
  }
}

export function createDino(phone) {
  db.prepare(`
    INSERT OR IGNORE INTO dinos (phone) VALUES (?)
  `).run(phone)
  return getDino(phone)
}

export function saveDino(dino) {
  db.prepare(`
    UPDATE dinos SET
      name         = @name,
      stage        = @stage,
      hunger       = @hunger,
      happiness    = @happiness,
      xp           = @xp,
      interactions = @interactions,
      url_feeds    = @url_feeds,
      personality  = @personality,
      memories     = @memories,
      history      = @history,
      last_seen    = strftime('%s','now')
    WHERE phone = @phone
  `).run({
    ...dino,
    personality: JSON.stringify(dino.personality),
    memories:    JSON.stringify(dino.memories),
    history:     JSON.stringify(dino.history),
  })
}

export function getAllDinos() {
  return db.prepare('SELECT phone, name, stage, xp, last_seen FROM dinos').all()
}

export default db
